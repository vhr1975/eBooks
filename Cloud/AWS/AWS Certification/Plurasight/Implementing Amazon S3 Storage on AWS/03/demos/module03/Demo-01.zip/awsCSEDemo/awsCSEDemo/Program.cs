﻿using Amazon;
using Amazon.KeyManagementService;
using Amazon.KeyManagementService.Model;
using Amazon.S3.Encryption;
using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace awsCSEDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string kmsKeyID = null;
            string keyId = "";
            string keySecret = "";
            var bucketName = "";
            var objectKey = "";

            using (var kmsClient = new AmazonKeyManagementServiceClient(
                keyId,
                keySecret, 
                RegionEndpoint.USEast1))
            {
                var response = kmsClient.CreateKey(new CreateKeyRequest());
                kmsKeyID = response.KeyMetadata.KeyId;

                var keyMetadata = response.KeyMetadata; 
                
                var kmsEncryptionMaterials = new EncryptionMaterials(kmsKeyID);

                var config = new AmazonS3CryptoConfiguration()
                {
                    RegionEndpoint = RegionEndpoint.USEast1
                };

                using (var s3Client = new AmazonS3EncryptionClient(
                    keyId,
                    keySecret, 
                    config, 
                    kmsEncryptionMaterials))
                {
                    var putRequest = new PutObjectRequest
                    {
                        BucketName = bucketName,
                        Key = objectKey,                            
                        ContentBody = "object content for client side encryption demo."
                    };

                    s3Client.PutObject(putRequest);

                    // get object and decrypt
                    var getRequest = new GetObjectRequest
                    {
                        BucketName = bucketName,
                        Key = objectKey
                    };

                    using (var getResponse = s3Client.GetObject(getRequest))
                    using (var stream = getResponse.ResponseStream)
                    using (var reader = new StreamReader(stream))
                    {
                        Console.WriteLine(reader.ReadToEnd());
                    }
                }               
            }
        }
    }
}